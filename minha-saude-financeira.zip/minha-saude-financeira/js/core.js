'use strict';
/* ===== CONFIGURAÇÕES DO APLICATIVO (edite aqui) ===== */
const APP_NAME='Minha saúde financeira';
const SITE_LUMANOIDS='';                       // coloque aqui o link do site da Lumanoids (ex.: 'https://...')
const WHATS_LUMANOIDS='https://wa.me/5511998889271'; // usado enquanto SITE_LUMANOIDS estiver vazio
const LINK_COMPRAS='https://applumanoids.github.io/lista-compras/';

/* ===== AUXILIARES ===== */
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const R=v=>'R$ '+v.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});
const MES=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const CATS=['🏠 Moradia','💡 Água, luz e gás','🛒 Alimentação','🚗 Transporte','💳 Cartão de crédito','📱 Internet e telefone','🏥 Saúde','📚 Educação','🎮 Lazer','💰 Dívidas e empréstimos','🐾 Pets','📦 Outros'];
const PAL=['#16a34a','#f59e0b','#3b82f6','#ec4899','#8b5cf6','#14b8a6','#ef4444','#84cc16','#f97316','#06b6d4','#a855f7','#64748b','#eab308'];
const pad=n=>String(n).padStart(2,'0');
const now=new Date();
const appYear=now.getFullYear();
const nowM=appYear+'-'+pad(now.getMonth()+1);
const today=nowM+'-'+pad(now.getDate());
const addM=(m,k)=>{let[y,n]=m.split('-').map(Number);let d=new Date(y,n-1+k,1);return d.getFullYear()+'-'+pad(d.getMonth()+1)};
const mk=(m,day)=>{let[y,n]=m.split('-').map(Number);return m+'-'+pad(Math.min(day,new Date(y,n,0).getDate()))};
const mo=b=>b.due.slice(0,7);
const late=b=>!b.paid&&b.due<today;
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const sumV=a=>a.reduce((s,x)=>s+x.value,0);
const catName=c=>c.split(' ').slice(1).join(' ')||c;

/* ===== DADOS (ficam só no aparelho: localStorage) ===== */
const DEF_CFG={sort:'due',showSal:true,payDay:0,pie:'cat'};
function norm(d){
 d=d&&typeof d=='object'?d:{};
 const o={...d};
 o.sal=d.sal&&typeof d.sal=='object'?d.sal:{};
 o.ended=d.ended&&typeof d.ended=='object'?d.ended:{};
 ['bills','cats','wish','goals'].forEach(k=>{o[k]=Array.isArray(d[k])?d[k]:[]});
 o.cfg={...DEF_CFG,...(d.cfg&&typeof d.cfg=='object'?d.cfg:{})};
 return o}
let S;try{S=norm(JSON.parse(localStorage.getItem('mc')))}catch(e){S=norm(null)}
const save=()=>{try{localStorage.setItem('mc',JSON.stringify(S))}catch(e){}};

/* ===== REGRAS DE CONTAS ===== */
function ensureFixed(m){let last={};S.bills.filter(b=>b.type=='fixed').forEach(b=>{if(!last[b.gid]||mo(b)>mo(last[b.gid]))last[b.gid]=b});
 for(const g in last){let b=last[g],x=mo(b),lim=addM(nowM,24);
  while(x<m&&x<lim){x=addM(x,1);if(S.ended[g]&&x>S.ended[g])break;S.bills.push({...b,id:uid(),due:mk(x,b.day),paid:false,paidAt:null})}}save()}
const sal=m=>{let k=Object.keys(S.sal).filter(x=>x<=m).sort().pop();return k?S.sal[k]:0};

/* ===== INSTALAÇÃO / FUNCIONAR SEM INTERNET ===== */
if('serviceWorker' in navigator&&/^https?:/.test(location.protocol))navigator.serviceWorker.register('sw.js').catch(()=>{});
try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch(e){}
